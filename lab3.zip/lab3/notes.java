/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;
import java.io.*;
import java.lang.String;

/**
 *
 * @author rfazal.bscs13seecs
 */
public class notes implements java.io.Serializable{
    public String username[];
    public String notes_user[];
    public notes() {
    }
    public String getNotes(String user) {
        for (int i =0; i< username.length;i++) {
            if (username[i].equals(user)) {
                return notes_user[i];
            }
        }
        return null;
    }
}
