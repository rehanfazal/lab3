/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;
import java.io.*;
import lab3.notes;
import java.net.Socket;
import java.util.Scanner;
/**
 *
 * @author rfazal.bscs13seecs
*/
public class Lab3 
 {

    /**
     * @param args the command line arguments
     */
    public static void main(String arg[]) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        notes n= null;
        int counter=0;
        String user= new String();
        String note= new String();
        while(true) {
            System.out.println("Enter Username: ");
            user=in.nextLine();
            System.out.println("Enter Notes of "+user);
            note= in.nextLine();
            System.out.println("If you want to quit press 1");
            int check= in.nextInt();
            if (check==1)
                break;
            
            n.username[counter]=user;
            n.notes_user[counter]=note;
        try{
            Socket s= new Socket("localhost",9010);
            ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
            out.writeObject(n);
            counter++;
            out.flush();
            out.close();
            }
        catch(IOException i){
          i.printStackTrace();
            }
       }

    }
    
}
