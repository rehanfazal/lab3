/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;
import lab3.notes;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import lab3.notes;

/**
 *
 * @author rfazal.bscs13seecs
 */
public class desearlization {
    public static void main (String args[]) throws IOException, ClassNotFoundException {
        notes n= null;
        ServerSocket listener = new ServerSocket(9010);
        int counter=0;
try{
	while(true){
        System.out.println("Server Ready For Connection");
	Socket socket = listener.accept();
        System.out.println("Server writing");
	try{
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            n = (notes) in.readObject();
            System.out.println("Username: "+n.username[counter]);
            System.out.println("Username: "+n.notes_user[counter]);
	}
	finally{
	    socket.close();
	}
        counter++;
	}
    }
    finally{
                listener.close();
           }
    }
}
